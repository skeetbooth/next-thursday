<div class='mapp-title'>{{{poi.title}}}</div>
<div class='mapp-body'>{{{poi.body}}}</div>
<div class='mapp-links'><a href='#' data-mapp-action='dir'><?php _e('Directions', 'mappress-google-maps-for-wordpress'); ?></a><div>