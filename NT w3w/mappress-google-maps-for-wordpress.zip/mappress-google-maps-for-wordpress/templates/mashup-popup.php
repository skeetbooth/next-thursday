<div class='mapp-title'><a href='{{{poi.url}}}' target='_blank'>{{{poi.title}}}</a></div>
<div class='mapp-body'>
	<a href='{{{poi.url}}}' target='_blank'>{{{poi.thumbnail}}}</a>
	{{{poi.body}}}
</div>
<div class='mapp-links'><a href='#' data-mapp-action='dir'><?php _e('Directions', 'mappress-google-maps-for-wordpress'); ?></a><div>
