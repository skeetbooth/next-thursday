<div class='mapp-header'>
	<?php echo $map->part('search'); ?>
	<?php echo $map->part('filters-toggle');?>
</div>

