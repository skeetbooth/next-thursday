<img class="mapp-icon" src="{{{poi.icon}}}">
<div class="mapp-title">{{{poi.title}}}</div>